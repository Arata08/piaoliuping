export type * from './hiteggs'
