export type * from './marquee'
