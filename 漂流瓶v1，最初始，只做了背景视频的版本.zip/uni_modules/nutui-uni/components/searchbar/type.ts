export const searchbarShape = ['square', 'round']
export type SearchbarShape = (typeof searchbarShape)[number]
