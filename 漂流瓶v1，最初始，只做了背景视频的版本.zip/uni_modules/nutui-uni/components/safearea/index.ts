export * from './safearea'
