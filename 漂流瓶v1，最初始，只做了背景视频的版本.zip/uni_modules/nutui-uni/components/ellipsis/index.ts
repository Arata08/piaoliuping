export type * from './ellipsis'
