export type * from './configprovider'
