export type RangeArrayValue = [number, number]
export type RangeValue = number | RangeArrayValue
