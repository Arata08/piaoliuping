export interface TPrizeItem {
  id: string | number
  prizeName: string
  prizeColor: string
  prizeImg: string
}
