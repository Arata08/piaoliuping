export interface AddressListOptions {
  [key: string]: string
}
